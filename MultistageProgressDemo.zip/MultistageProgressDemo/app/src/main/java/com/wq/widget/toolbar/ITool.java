package com.wq.widget.toolbar;

import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

/**
 * Created by WQ on 2017/8/2.
 */

public interface ITool extends TextWatcher {
    /**
     * 获取工具视图
     * @return
     */
    View getView();

    /**
     * 依附到工具条上
     * @param toolBar
     */
    void attachToolBar(ToolBar toolBar);

    /**
     * 动作
     * @param textView
     */
    void action(TextView textView);
}

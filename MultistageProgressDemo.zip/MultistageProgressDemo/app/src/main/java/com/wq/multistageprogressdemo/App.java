package com.wq.multistageprogressdemo;

import android.app.Application;

import io.realm.Realm;

/**
 * Created by WQ on 2017/8/3.
 */

public class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        Realm.init(this);
    }
}

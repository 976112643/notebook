package com.wq.multistageprogressdemo;

import io.realm.Realm;
import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

/**
 * Created by WQ on 2017/8/3.
 */

public class NoteCategory extends RealmObject {
    public long addtime;
    public long updatetime;
    @PrimaryKey
    public String _id=generateId();
    public String name;



    private synchronized String generateId() {
        String id = String.valueOf(Realm.getDefaultInstance().where(NoteCategory.class).count() + 1);
        return id;
    }
}

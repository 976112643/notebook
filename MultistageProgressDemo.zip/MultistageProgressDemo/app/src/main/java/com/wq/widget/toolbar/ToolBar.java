package com.wq.widget.toolbar;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.HashSet;
import java.util.Map;
import java.util.WeakHashMap;

/**
 * Created by WQ on 2017/8/2.
 */

public class ToolBar extends HorizontalScrollView implements View.OnClickListener{
    LinearLayout linearLayout;
    Map<View,ITool> toolSet=new WeakHashMap<>();
    TextView attatchTextView;
    private void initView() {
        linearLayout=new LinearLayout(getContext());
        linearLayout.setOrientation(LinearLayout.HORIZONTAL);
        addView(linearLayout,generateDefaultLayoutParams());
    }

    public void attachView(TextView tagretView){
        this.attatchTextView=tagretView;
    }

    /**
     * 添加工具
     * @param tools
     */
    public  void addTool(ITool ... tools){
        checkSelfVaild();
        for (ITool tool : tools) {
            if(!toolSet.containsValue(tool)) {
                View toolView = tool.getView();
                toolSet.put(toolView,tool);
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(toolView.getLayoutParams());
                linearLayout.addView(toolView, layoutParams);
                tool.attachToolBar(this);
                toolView.setOnClickListener(this);
            }
        }
    }

    public void removeAllTool(){
        toolSet.clear();
    }

    @Override
    public void onClick(View v) {
        checkSelfVaild();
        ITool tool=toolSet.get(v);
        if(tool!=null) {
            tool.action(attatchTextView);
        }
    }
















    void checkSelfVaild(){
        if (attatchTextView==null)throw  new IllegalStateException("attatchTextView 未被正常初始化");
    }

    public ToolBar(Context context) {
        super(context);
        initView();
    }


    public ToolBar(Context context, AttributeSet attrs) {
        super(context, attrs);
        initView();
    }

    public ToolBar(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView();
    }

    public ToolBar(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }


}

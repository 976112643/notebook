package com.wq.multistageprogressdemo;

import android.text.TextUtils;

import io.realm.Realm;
import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

import static com.wq.multistageprogressdemo.DBUtil.executeTransaction;

/**
 * Created by WQ on 2017/8/3.
 */

public class NoteTag extends RealmObject {
    public long addtime = System.currentTimeMillis();
    public long updatetime = System.currentTimeMillis();
    @PrimaryKey
    public String _id = generateId();
    public String name;

    public NoteTag() {
    }

    public NoteTag(String name) {
        this.name = String.valueOf(name);
        _id = String.valueOf(name.hashCode());
    }

    public static void addOrUpdate(final NoteTag notetag) {
        executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                realm.insertOrUpdate(notetag);
            }
        });
    }

    public static void addOrUpdate(String tagName) {
        if (TextUtils.isEmpty(tagName)) return;
        addOrUpdate(new NoteTag(tagName));
    }


    private synchronized String generateId() {
        String id = String.valueOf(Realm.getDefaultInstance().where(NoteTag.class).count() + 1);
        return id;
    }
}

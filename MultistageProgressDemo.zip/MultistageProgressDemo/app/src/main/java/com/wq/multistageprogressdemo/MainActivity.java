package com.wq.multistageprogressdemo;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.widget.EditText;

import com.wq.widget.MultistageProgress;
import com.wq.widget.toolbar.LimitLineTool;
import com.wq.widget.toolbar.ToolBar;

import io.realm.Realm;
import io.realm.RealmResults;

public class MainActivity extends AppCompatActivity {

    ToolBar toolBar;
    EditText editContent;
    Realm realm=Realm.getDefaultInstance();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolBar= (ToolBar) findViewById(R.id.toolBar);
        editContent= (EditText) findViewById(R.id.editContent);
        toolBar.attachView(editContent);
        LimitLineTool lineTool=new LimitLineTool(this);
        lineTool.setImageResource(R.mipmap.ic_launcher);
        toolBar.addTool(lineTool);

        MultistageProgress multistageProgress= (MultistageProgress) findViewById(R.id.multistageProgress1);
        multistageProgress.autoChange(0,100,15*1000);
        MultistageProgress multistageProgress2= (MultistageProgress) findViewById(R.id.multistageProgress2);
        multistageProgress2.setColors(new int[]{Color.RED,Color.GREEN,Color.BLUE},new float[]{1f,2f,3f});
        multistageProgress2.autoChange(0,100,15*1000);
        Note note= new Note();
        note.content="哈哈";
        note.tag="哈";
        Note.addOrUpdate(note);

       RealmResults<Note> notes= realm.where(Note.class).findAll();
        Log.e("weiquan","notes:"+notes);
        RealmResults<NoteTag>noteTags=realm.where(NoteTag.class).findAll();
        Log.e("weiquan","noteTags:"+notes);
    }

}

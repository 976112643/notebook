package com.wq.multistageprogressdemo;

import io.realm.Realm;
import io.realm.RealmModel;

/**
 * Created by WQ on 2017/8/3.
 */

public class DBUtil {
    public static void executeTransaction(Realm.Transaction transaction){
        executeTransaction(Realm.getDefaultInstance(),transaction);
    }

    public static void executeTransaction(Realm realm,Realm.Transaction transaction){
        if (realm.isInTransaction()) {
            transaction.execute(realm);
        } else {
            realm.executeTransaction(transaction);
        }
    }
}

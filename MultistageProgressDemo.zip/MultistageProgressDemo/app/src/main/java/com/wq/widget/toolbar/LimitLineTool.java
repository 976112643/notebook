package com.wq.widget.toolbar;

import android.content.Context;
import android.text.Editable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;



/**
 * Created by WQ on 2017/8/2.
 */

public class LimitLineTool extends ImageView implements ITool{
    ToolBar toolBar;

    public LimitLineTool(Context context) {
        super(context);
    }

    public LimitLineTool(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public LimitLineTool(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public LimitLineTool(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }

    @Override
    public View getView() {
        setLayoutParams(new LinearLayout.LayoutParams(60,60));
        return this;
    }

    @Override
    public void attachToolBar(ToolBar toolBar) {
        this.toolBar=toolBar;
    }

    @Override
    public void action(TextView textView) {
        int index=textView.getSelectionEnd();
        Editable editable= textView.getEditableText();
        editable.insert(index,"---\n");
    }

    void addStartBr( Editable editable, int index){
        char chars[]=new char[1];
        editable.getChars(index,index+1,chars,0);
        if(chars[0]!='\n')
            editable.insert(index,"\n");
    }
    void addEndBr(Editable editable, int index){
        char chars[]=new char[1];
        editable.getChars(index,Math.min(index+1,editable.length()),chars,0);
        if(chars[0]!='\n')
            editable.insert(index,"\n");
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {

    }

    @Override
    public void afterTextChanged(Editable s) {

    }
}

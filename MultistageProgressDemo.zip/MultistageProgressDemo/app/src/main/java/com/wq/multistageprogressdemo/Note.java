package com.wq.multistageprogressdemo;

import io.realm.Realm;
import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

import static com.wq.multistageprogressdemo.DBUtil.executeTransaction;

/**
 * Created by WQ on 2017/8/3.
 */

public class Note extends RealmObject {
    public String content;
    public long addtime=System.currentTimeMillis();
    public long updatetime=System.currentTimeMillis();
    @PrimaryKey
    public String _id=generateId();
    public String tag;
    public String tagIds;
    public String category_id;
    public int type = TYPE_TXT;
    public final static int TYPE_TXT = 0;
    public final static int TYPE_IMG = 1;
    public final static int TYPE_MEDIA = 2;

    public static void addOrUpdate(final Note note) {
        executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                realm. insertOrUpdate(note);
                NoteTag.addOrUpdate(note.tag);
            }
        });
    }

    private synchronized String generateId() {
        String id = String.valueOf(Realm.getDefaultInstance().where(Note.class).count() + 1);
        return id;
    }
}
